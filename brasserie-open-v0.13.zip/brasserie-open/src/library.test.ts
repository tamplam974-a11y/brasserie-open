import { describe, expect, it } from 'vitest';
import { compute, computeWater, defaultRecipe, recipeToHtml, sanitize } from './library';

describe('bibliothèque', () => {
  it('répare une recette incomplète ou inconnue', () => {
    const d = sanitize({ styleId: 'XX', mrows: [{ id: 'inconnu', kg: '2' }], water: { ratio: 5 } });
    expect(d.styleId).toBe('21A');
    expect(d.mrows).toEqual([]);
    expect(d.water.ratio).toBe('3');
  });
  it('calcule la recette par défaut', () => {
    const r = compute(defaultRecipe());
    expect(r?.og).toBeGreaterThan(1.05);
    expect(r?.hopIbu).toHaveLength(2);
  });
  it('calcule les volumes d’eau par défaut', () => {
    const { water, strikeC } = computeWater(defaultRecipe());
    expect(water?.strikeL).toBeCloseTo(16.5, 6);
    expect(strikeC).toBeGreaterThan(66);
  });
  it('exporte en HTML échappé, avec des données réimportables', () => {
    const d = defaultRecipe('Test <b>x</b>');
    const html = recipeToHtml(d);
    expect(html).not.toContain('<b>x</b>');
    expect(html).toContain('&lt;b&gt;');
    const m = html.match(/id="brasserie-open-recette">([\s\S]*?)<\/script>/);
    expect(sanitize(JSON.parse(m![1]))).toEqual(d);
  });
});

describe('anciens styles', () => {
  it('convertit les anciens identifiants', () => {
    expect(sanitize({ styleId: '15A' }).styleId).toBe('10A');
    expect(sanitize({ styleId: '27' }).styleId).toBe('17D');
    expect(sanitize({ styleId: '27L' }).styleId).toBe('27L');
  });
});
