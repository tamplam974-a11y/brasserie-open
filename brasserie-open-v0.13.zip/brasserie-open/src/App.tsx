import { useEffect, useState } from 'react';
import RecipeBuilder from './RecipeBuilder';
import {
  abvSimple,
  apparentAttenuation,
  brixToSg,
  dilutionToTargetGravity,
  gravityAfterVolumeChange,
  ibuContributions,
  refractometerFinalGravity,
  type HopAddition,
} from './engine';

const num = (s: string) => parseFloat(s.replace(',', '.'));
const positive = (...v: number[]) => v.every((x) => Number.isFinite(x) && x > 0);
const fmt = (x: number, d = 3) =>
  x.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d });

function Field(p: { label: string; value: string; onChange: (v: string) => void; unit?: string }) {
  return (
    <label className="field">
      <span>{p.label}</span>
      <div>
        <input inputMode="decimal" value={p.value} onChange={(e) => p.onChange(e.target.value)} />
        {p.unit && <em>{p.unit}</em>}
      </div>
    </label>
  );
}

function Result({ label, value }: { label: string; value: string }) {
  return (
    <div className="result">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

const Hint = () => <p className="hint">Saisissez des valeurs valides pour voir le résultat.</p>;

function Refractometer() {
  const [ob, setOb] = useState('12');
  const [cb, setCb] = useState('7');
  const [k, setK] = useState('1,04');
  const [OB, CB, K] = [num(ob), num(cb), num(k)];
  const valid = positive(OB, CB, K);
  const og = brixToSg(OB / K);
  const fg = refractometerFinalGravity(OB, CB, K);
  return (
    <section>
      <h2>Réfractomètre</h2>
      <p>Estime la densité finale et l’alcool à partir de deux lectures en °Brix (avant et pendant la fermentation).</p>
      <Field label="Brix initial" value={ob} onChange={setOb} unit="°Bx" />
      <Field label="Brix actuel" value={cb} onChange={setCb} unit="°Bx" />
      <Field label="Facteur de correction moût" value={k} onChange={setK} />
      {valid ? (
        <>
          <Result label="Densité initiale" value={fmt(og)} />
          <Result label="Densité actuelle estimée" value={fmt(fg)} />
          <Result label="Alcool estimé" value={`${fmt(abvSimple(og, fg), 1)} %`} />
          <Result label="Atténuation apparente" value={`${fmt(apparentAttenuation(og, fg), 0)} %`} />
        </>
      ) : (
        <Hint />
      )}
    </section>
  );
}

function Dilution() {
  const [v, setV] = useState('20');
  const [sg, setSg] = useState('1,060');
  const [t, setT] = useState('1,050');
  const [v2, setV2] = useState('25');
  const [V, SG, T, V2] = [num(v), num(sg), num(t), num(v2)];
  const dil = positive(V, SG - 1, T - 1) ? dilutionToTargetGravity(V, SG, T) : null;
  const water = dil?.waterToAddL ?? 0;
  return (
    <section>
      <h2>Dilution et volume</h2>
      <p>Volume à atteindre pour une densité cible, en conservant la même quantité de sucre.</p>
      <Field label="Volume actuel" value={v} onChange={setV} unit="L" />
      <Field label="Densité actuelle" value={sg} onChange={setSg} />
      <Field label="Densité cible" value={t} onChange={setT} />
      {dil ? (
        <>
          <Result label="Volume final" value={`${fmt(dil.finalVolumeL, 1)} L`} />
          <Result
            label={water >= 0 ? 'Eau à ajouter' : 'Volume à évaporer'}
            value={`${fmt(Math.abs(water), 1)} L`}
          />
        </>
      ) : (
        <Hint />
      )}
      <h3>Recalibrage après changement de volume</h3>
      <Field label="Nouveau volume (évaporation ou eau)" value={v2} onChange={setV2} unit="L" />
      {positive(V, SG - 1, V2) ? (
        <Result label="Nouvelle densité" value={fmt(gravityAfterVolumeChange(V, SG, V2))} />
      ) : (
        <Hint />
      )}
    </section>
  );
}

interface HopRow { name: string; grams: string; aa: string; min: string }

function Bitterness() {
  const [vol, setVol] = useState('20');
  const [sg, setSg] = useState('1,050');
  const [rows, setRows] = useState<HopRow[]>([
    { name: 'Magnum', grams: '20', aa: '12', min: '60' },
    { name: 'Saaz', grams: '30', aa: '3,5', min: '10' },
  ]);
  const edit = (i: number, key: keyof HopRow, value: string) =>
    setRows(rows.map((r, j) => (j === i ? { ...r, [key]: value } : r)));
  const additions: HopAddition[] = rows.map((r) => ({
    name: r.name,
    grams: num(r.grams),
    alphaAcidPct: num(r.aa),
    boilTimeMin: num(r.min),
  }));
  const valid = positive(num(vol), num(sg) - 1);
  const parts = valid
    ? ibuContributions(
        additions.map((a) => (positive(a.grams, a.alphaAcidPct) && a.boilTimeMin >= 0 ? a : { ...a, grams: 0 })),
        num(vol),
        num(sg),
      )
    : [];
  const total = parts.reduce((s, x) => s + (Number.isFinite(x) ? x : 0), 0);
  return (
    <section>
      <h2>Amertume multi-houblons</h2>
      <p>IBU selon la formule de Tinseth, avec la contribution de chaque addition.</p>
      <Field label="Volume en fin d’ébullition" value={vol} onChange={setVol} unit="L" />
      <Field label="Densité d’ébullition" value={sg} onChange={setSg} />
      {rows.map((r, i) => (
        <div className="hop" key={i}>
          <input aria-label="Houblon" value={r.name} onChange={(e) => edit(i, 'name', e.target.value)} />
          <input aria-label="Grammes" inputMode="decimal" value={r.grams} onChange={(e) => edit(i, 'grams', e.target.value)} />
          <input aria-label="Alpha-acides en %" inputMode="decimal" value={r.aa} onChange={(e) => edit(i, 'aa', e.target.value)} />
          <input aria-label="Minutes" inputMode="decimal" value={r.min} onChange={(e) => edit(i, 'min', e.target.value)} />
          <button onClick={() => setRows(rows.filter((_, j) => j !== i))} aria-label="Supprimer">×</button>
        </div>
      ))}
      <p className="hint">Colonnes : houblon, grammes, % alpha-acides, minutes d’ébullition.</p>
      <button className="add" onClick={() => setRows([...rows, { name: '', grams: '', aa: '', min: '' }])}>
        + Ajouter un houblon
      </button>
      {valid ? (
        <>
          <Result label="Amertume totale" value={`${fmt(total, 1)} IBU`} />
          {rows.map((r, i) => (
            <div className="bar" key={i}>
              <span>{r.name || `Houblon ${i + 1}`}</span>
              <div><i style={{ width: `${total > 0 ? ((parts[i] ?? 0) / total) * 100 : 0}%` }} /></div>
              <b>{fmt(parts[i] ?? 0, 1)}</b>
            </div>
          ))}
        </>
      ) : (
        <Hint />
      )}
    </section>
  );
}

const TOOLS = [
  { id: 'recette', label: 'Recette', view: <RecipeBuilder /> },
  { id: 'refracto', label: 'Réfractomètre', view: <Refractometer /> },
  { id: 'dilution', label: 'Dilution et volume', view: <Dilution /> },
  { id: 'ibu', label: 'Amertume', view: <Bitterness /> },
];

type Theme = 'light' | 'dark';

function initialTheme(): Theme {
  try {
    return localStorage.getItem('theme') === 'dark' ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

export default function App() {
  const [tool, setTool] = useState(TOOLS[0].id);
  const [theme, setTheme] = useState<Theme>(initialTheme);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem('theme', theme);
    } catch {
      /* stockage indisponible : le choix ne sera pas mémorisé */
    }
  }, [theme]);
  return (
    <main>
      <header>
        <div>
          <h1>Brasserie Open</h1>
          <p className="sub">Boîte à outils gratuite du brasseur amateur</p>
        </div>
        <button
          className="theme"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          aria-label={theme === 'dark' ? 'Passer au thème clair' : 'Passer au thème sombre'}
        >
          {theme === 'dark' ? '☀ Clair' : '☾ Sombre'}
        </button>
      </header>
      <nav>
        {TOOLS.map((t) => (
          <button key={t.id} className={t.id === tool ? 'on' : ''} onClick={() => setTool(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>
      {TOOLS.find((t) => t.id === tool)?.view}
      <footer>Calculs indicatifs : vérifiez toujours avec vos propres mesures.</footer>
    </main>
  );
}
