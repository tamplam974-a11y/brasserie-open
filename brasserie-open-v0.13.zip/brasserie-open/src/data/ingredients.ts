/** Valeurs typiques génériques, à ajuster selon la fiche technique de votre fournisseur. */
export interface Malt { id: string; name: string; extractPct: number; ebc: number }
export interface Hop { id: string; name: string; aa: number; aroma: string }
export interface Yeast { id: string; name: string; attenuationPct: number; tempC: string }

export const MALTS: Malt[] = [
  { id: 'pils', name: 'Pilsner', extractPct: 80, ebc: 3.5 },
  { id: 'pale', name: 'Pale Ale', extractPct: 79, ebc: 6 },
  { id: 'mo', name: 'Maris Otter', extractPct: 80, ebc: 5.5 },
  { id: 'vienna', name: 'Vienna', extractPct: 79, ebc: 8 },
  { id: 'munich', name: 'Munich', extractPct: 78, ebc: 20 },
  { id: 'wheat', name: 'Froment malté', extractPct: 82, ebc: 4 },
  { id: 'carapils', name: 'Carapils / dextrine', extractPct: 74, ebc: 4 },
  { id: 'cara30', name: 'Caramel 30 EBC', extractPct: 75, ebc: 30 },
  { id: 'cara120', name: 'Caramel 120 EBC', extractPct: 74, ebc: 120 },
  { id: 'choc', name: 'Chocolat', extractPct: 65, ebc: 800 },
  { id: 'roast', name: 'Orge torréfiée', extractPct: 60, ebc: 1000 },
  { id: 'oats', name: 'Flocons d’avoine', extractPct: 70, ebc: 3 },
  { id: 'sugar', name: 'Sucre candi blond', extractPct: 100, ebc: 2 },
];

export const HOPS: Hop[] = [
  { id: 'magnum', name: 'Magnum', aa: 13, aroma: 'amertume neutre' },
  { id: 'target', name: 'Target', aa: 10, aroma: 'herbes, résine' },
  { id: 'challenger', name: 'Challenger', aa: 7.5, aroma: 'épices, cèdre' },
  { id: 'ekg', name: 'East Kent Goldings', aa: 5, aroma: 'miel, fleurs' },
  { id: 'fuggles', name: 'Fuggles', aa: 4.5, aroma: 'terre, bois' },
  { id: 'saaz', name: 'Saaz', aa: 3.5, aroma: 'herbes, épices' },
  { id: 'hallertau', name: 'Hallertau Mittelfrüh', aa: 4, aroma: 'floral, épicé' },
  { id: 'styrian', name: 'Styrian Goldings', aa: 4, aroma: 'floral, terre' },
  { id: 'cascade', name: 'Cascade', aa: 6, aroma: 'pamplemousse, fleurs' },
  { id: 'centennial', name: 'Centennial', aa: 9.5, aroma: 'agrumes, fleurs' },
  { id: 'citra', name: 'Citra', aa: 12.5, aroma: 'agrumes, fruits tropicaux' },
  { id: 'mosaic', name: 'Mosaic', aa: 11.5, aroma: 'tropical, baies' },
  { id: 'simcoe', name: 'Simcoe', aa: 13, aroma: 'résine, fruits à noyau' },
  { id: 'amarillo', name: 'Amarillo', aa: 9, aroma: 'orange, fleurs' },
  { id: 'galaxy', name: 'Galaxy', aa: 14, aroma: 'fruit de la passion' },
  { id: 'nelson', name: 'Nelson Sauvin', aa: 12, aroma: 'raisin blanc, groseille' },
];

export const YEASTS: Yeast[] = [
  { id: 'us05', name: 'Ale américaine neutre (type US-05)', attenuationPct: 80, tempC: '15–22' },
  { id: 's04', name: 'Ale anglaise (type S-04)', attenuationPct: 75, tempC: '15–20' },
  { id: 'k97', name: 'Kölsch / ale allemande (type K-97)', attenuationPct: 80, tempC: '15–20' },
  { id: 'wb06', name: 'Blanche / weizen (type WB-06)', attenuationPct: 75, tempC: '18–24' },
  { id: 'belge', name: 'Ale belge d’abbaye', attenuationPct: 80, tempC: '18–26' },
  { id: 'saison', name: 'Saison (type diastaticus)', attenuationPct: 88, tempC: '20–32' },
  { id: 'lager', name: 'Lager (type W-34/70)', attenuationPct: 82, tempC: '10–15' },
  { id: 'kveik', name: 'Kveik', attenuationPct: 78, tempC: '25–38' },
];
