import { useRef, useState, type KeyboardEvent, type PointerEvent } from 'react';

import { HOPS, MALTS, YEASTS } from './data/ingredients';
import { STYLES, type Range } from './data/styles';
import {
  USE_DEFAULTS, compute, computeWater, defaultRecipe, loadLibrary, newId, parseRecipeHtml, recipeToHtml,
  saveLibrary, type HopRow, type Library, type MaltRow, type MashStep, type RecipeState, type WaterParams,
} from './library';

const num = (s: string) => parseFloat(s.replace(',', '.'));
const fmt = (x: number, d = 1) =>
  x.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d });

const fmtIn = (x: number, d: number) => String(Math.round(x * 10 ** d) / 10 ** d).replace('.', ',');

/** Champ de poids avec boutons + et − (et flèches haut/bas du clavier). */
function Stepper(p: { label: string; value: string; step: number; decimals: number; onChange: (v: string) => void }) {
  const bump = (dir: 1 | -1) =>
    p.onChange(fmtIn(Math.max(0, (num(p.value) || 0) + dir * p.step), p.decimals));
  return (
    <div className="stepper">
      <input
        aria-label={p.label}
        inputMode="decimal"
        value={p.value}
        onChange={(e) => p.onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
            e.preventDefault();
            bump(e.key === 'ArrowUp' ? 1 : -1);
          }
        }}
      />
      <span className="steps">
        <button type="button" tabIndex={-1} aria-label={`Augmenter (${p.label})`} onClick={() => bump(1)}>+</button>
        <button type="button" tabIndex={-1} aria-label={`Diminuer (${p.label})`} onClick={() => bump(-1)}>−</button>
      </span>
    </div>
  );
}

function Gauge(p: {
  label: string; value: number; range: Range; d?: number;
  step?: number; hint?: string; onDragStart?: () => void; onDrag?: (v: number) => void;
}) {
  const [lo, hi] = p.range;
  const min = lo - (hi - lo), max = hi + (hi - lo);
  const pos = (x: number) => Math.min(100, Math.max(0, ((x - min) / (max - min)) * 100));
  const ok = p.value >= lo && p.value <= hi;
  const d = p.d ?? 1;
  const track = useRef<HTMLDivElement>(null);
  const live = !!p.onDrag;
  const valueAt = (clientX: number) => {
    const b = track.current!.getBoundingClientRect();
    const t = Math.min(1, Math.max(0, (clientX - b.left) / b.width));
    return min + t * (max - min);
  };
  const handlers = live
    ? {
        role: 'slider' as const, tabIndex: 0, title: p.hint, 'aria-label': p.label,
        'aria-valuemin': min, 'aria-valuemax': max, 'aria-valuenow': p.value,
        onPointerDown: (e: PointerEvent<HTMLDivElement>) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          p.onDragStart?.();
          p.onDrag!(valueAt(e.clientX));
        },
        onPointerMove: (e: PointerEvent<HTMLDivElement>) => {
          if (e.currentTarget.hasPointerCapture(e.pointerId)) p.onDrag!(valueAt(e.clientX));
        },
        onKeyDown: (e: KeyboardEvent<HTMLDivElement>) => {
          if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
          e.preventDefault();
          p.onDragStart?.();
          p.onDrag!(p.value + (e.key === 'ArrowRight' ? 1 : -1) * (p.step ?? (max - min) / 100));
        },
      }
    : {};
  return (
    <div className="gauge">
      <div className="gl"><span>{p.label}</span><b className={ok ? 'ok' : 'ko'}>{fmt(p.value, d)}</b></div>
      <div className={live ? 'track live' : 'track'} ref={track} {...handlers}>
        <i className="band" style={{ left: `${pos(lo)}%`, width: `${pos(hi) - pos(lo)}%` }} />
        <i className="mark" style={{ left: `${pos(p.value)}%` }} />
      </div>
      <small>Style : {fmt(lo, d)} à {fmt(hi, d)}</small>
    </div>
  );
}

const WATER_FIELDS: [keyof WaterParams, string][] = [
  ['ratio', 'Eau/grain (L/kg)'], ['absorb', 'Absorption (L/kg)'], ['evap', 'Évaporation (L/h)'],
  ['boil', 'Ébullition (min)'], ['loss', 'Pertes (L)'], ['grainTemp', 'Grain (°C)'],
];

export default function RecipeBuilder() {
  const [lib, setLib] = useState<Library>(loadLibrary);
  const [init] = useState<RecipeState>(() => lib.items.find((x) => x.id === lib.current)!.data);
  const [name, setName] = useState(init.name);
  const [styleId, setStyleId] = useState(init.styleId);
  const [vol, setVol] = useState(init.vol);
  const [eff, setEff] = useState(init.eff);
  const [yeastId, setYeastId] = useState(init.yeastId);
  const [mrows, setM] = useState<MaltRow[]>(init.mrows);
  const [hrows, setH] = useState<HopRow[]>(init.hrows);
  const [mash, setMash] = useState<MashStep[]>(init.mash);
  const [water, setWater] = useState<WaterParams>(init.water);
  const [msg, setMsg] = useState('');
  const snapshot = (): RecipeState => ({ name, styleId, vol, eff, yeastId, mrows, hrows, mash, water });
  const apply = (d: RecipeState) => {
    setName(d.name); setStyleId(d.styleId); setVol(d.vol); setEff(d.eff); setYeastId(d.yeastId);
    setM(d.mrows); setH(d.hrows); setMash(d.mash); setWater(d.water);
  };
  const flash = (t: string) => { setMsg(t); setTimeout(() => setMsg(''), 2500); };
  const stored = lib.items.find((x) => x.id === lib.current);
  const dirty = !stored || JSON.stringify(stored.data) !== JSON.stringify(snapshot());
  const guard = () => !dirty || window.confirm('Abandonner les modifications non mémorisées ?');
  const persist = (next: Library) => {
    setLib(next);
    try { saveLibrary(next); return true; } catch { flash('Mémorisation impossible dans ce navigateur'); return false; }
  };
  const save = () => {
    const nm = name.trim() || 'Sans titre';
    setName(nm);
    const items = lib.items.map((x) => (x.id === lib.current ? { ...x, data: { ...snapshot(), name: nm } } : x));
    if (persist({ ...lib, items })) flash('Recette mémorisée ✓');
  };
  const add = (data: RecipeState) => {
    const id = newId();
    persist({ current: id, items: [...lib.items, { id, data }] });
    apply(data);
  };
  const newRecipe = () => { if (guard()) add(defaultRecipe('Nouvelle recette')); };
  const switchTo = (id: string) => {
    const it = lib.items.find((x) => x.id === id);
    if (!it || id === lib.current || !guard()) return;
    persist({ ...lib, current: id });
    apply(it.data);
  };
  const remove = () => {
    if (!window.confirm(`Supprimer « ${stored?.data.name ?? name} » ?`)) return;
    const items = lib.items.filter((x) => x.id !== lib.current);
    if (items.length) { persist({ current: items[0].id, items }); apply(items[0].data); }
    else { const d = defaultRecipe('Nouvelle recette'); const id = newId(); persist({ current: id, items: [{ id, data: d }] }); apply(d); }
  };
  const exportHtml = () => {
    const url = URL.createObjectURL(new Blob([recipeToHtml(snapshot())], { type: 'text/html' }));
    const a = document.createElement('a');
    a.href = url;
    a.download = `${(name.trim() || 'recette').replace(/[^\p{L}\p{N}]+/gu, '-')}.html`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const importHtml = (file: File | undefined) => {
    if (!file || !guard()) return;
    file.text().then((t) => {
      const d = parseRecipeHtml(t);
      if (d) { add(d); flash('Recette importée ✓'); } else flash('Fichier non reconnu');
    });
  };
  const style = STYLES.find((s) => s.id === styleId)!;
  const yeast = YEASTS.find((y) => y.id === yeastId)!;
  const V = num(vol), E = num(eff);
  const valid = V > 0 && E > 0;
  const r = compute(snapshot());
  const { water: mw, strikeC } = computeWater(snapshot());
  // Glisser un curseur du bilan : tous les malts (ou tous les houblons amérisants) sont mis à l’échelle.
  const base = useRef<{ mrows: MaltRow[]; hrows: HopRow[]; og: number; ibu: number } | null>(null);
  const startDrag = () => { if (r) base.current = { mrows, hrows, og: r.og, ibu: r.ibu }; };
  const dragOg = (v: number) => {
    const b = base.current;
    if (!b || b.og <= 1) return;
    const f = (Math.round(v * 1000) / 1000 - 1) / (b.og - 1);
    if (f > 0) setM(b.mrows.map((m) => ({ ...m, kg: fmtIn((num(m.kg) || 0) * f, 2) })));
  };
  const dragIbu = (v: number) => {
    const b = base.current;
    if (!b || b.ibu <= 0) return;
    const f = Math.max(0, Math.round(v)) / b.ibu;
    setH(b.hrows.map((h) => (h.use === 'dryhop' ? h : { ...h, grams: fmtIn((num(h.grams) || 0) * f, 1) })));
  };
  const totalKg = mrows.reduce((s, m) => s + (num(m.kg) || 0), 0);
  return (
    <section className="recipe">
      <div className="inputs">
      <div className="libbar">
        <select aria-label="Bibliothèque de recettes" value={lib.current} onChange={(e) => switchTo(e.target.value)}>
          {lib.items.map((x) => <option key={x.id} value={x.id}>{x.data.name}</option>)}
        </select>
        <input className="nm" aria-label="Nom de la recette" placeholder="Nom de la recette" title="Modifiez le nom, puis cliquez sur Mémoriser" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="save" onClick={save}>Mémoriser</button>
        <button className="add" onClick={newRecipe}>Nouvelle</button>
        <button className="add" onClick={remove}>Supprimer</button>
        <button className="add" onClick={exportHtml}>Exporter HTML</button>
        <label className="add">Importer HTML
          <input type="file" accept=".html,text/html" hidden onChange={(e) => { importHtml(e.target.files?.[0]); e.target.value = ''; }} />
        </label>
        <span className="saved">{msg || (dirty ? '● non mémorisé' : '')}</span>
      </div>
      <div className="top4">
        <label className="field"><span>Style</span>
          <select value={styleId} onChange={(e) => setStyleId(e.target.value)}>
            {STYLES.map((st) => <option key={st.id} value={st.id}>{st.id} – {st.name}</option>)}
          </select>
        </label>
        <label className="field"><span>Volume (L)</span>
          <input inputMode="decimal" value={vol} onChange={(e) => setVol(e.target.value)} /></label>
        <label className="field"><span>Rendement (%)</span>
          <input inputMode="decimal" value={eff} onChange={(e) => setEff(e.target.value)} /></label>
      </div>
      <div className="sec"><h3>Malts ({fmt(totalKg, 2)} kg)</h3><button className="add" onClick={() => setM([...mrows, { id: 'pils', kg: '1' }])}>+ Malt</button></div>
      <div className="row mrow head" aria-hidden="true"><span>Malt</span><span>Kilos</span><span>%</span><span /></div>
      {mrows.map((m, i) => (
        <div className="row mrow" key={i}>
          <select value={m.id} onChange={(e) => setM(mrows.map((x, j) => (j === i ? { ...x, id: e.target.value } : x)))}>
            {MALTS.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <Stepper label="Kilos" step={0.1} decimals={2} value={m.kg}
            onChange={(v) => setM(mrows.map((x, j) => (j === i ? { ...x, kg: v } : x)))} />
          <output className="pct" aria-label="Pourcentage du malt">{totalKg > 0 ? `${fmt(((num(m.kg) || 0) / totalKg) * 100, 1)} %` : '–'}</output>
          <button onClick={() => setM(mrows.filter((_, j) => j !== i))} aria-label="Supprimer">×</button>
        </div>
      ))}
      <div className="sec"><h3>Houblons</h3><button className="add" onClick={() => setH([...hrows, { id: 'cascade', grams: '20', aa: '6', use: 'boil', min: '15', temp: '100' }])}>+ Houblon</button></div>
      <div className="hops">
        <div className="row hrow head" aria-hidden="true">
          <span>Houblon</span><span>Grammes</span><span>% alpha-acides</span><span>Usage</span>
          <span>Minutes</span><span>°C</span><span>IBU</span><span />
        </div>
        {hrows.map((h, i) => {
          const up = (p: Partial<HopRow>) => setH(hrows.map((x, j) => (j === i ? { ...x, ...p } : x)));
          return (
            <div className="row hrow" key={i}>
              <select aria-label="Houblon" value={h.id} onChange={(e) => {
                const d = HOPS.find((x) => x.id === e.target.value)!;
                up({ id: d.id, aa: String(d.aa).replace('.', ',') });
              }}>
                {HOPS.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
              <Stepper label="Grammes" step={5} decimals={1} value={h.grams} onChange={(v) => up({ grams: v })} />
              <input aria-label="Alpha-acides en %" inputMode="decimal" value={h.aa} onChange={(e) => up({ aa: e.target.value })} />
              <select aria-label="Usage" value={h.use} onChange={(e) => up({ use: e.target.value as HopRow['use'], ...USE_DEFAULTS[e.target.value as HopRow['use']] })}>
                <option value="boil">Ébullition</option>
                <option value="fwh">FWH</option>
                <option value="hopstand">Hopstand</option>
                <option value="dryhop">Dry hop</option>
              </select>
              <input aria-label="Minutes" inputMode="decimal" value={h.min} disabled={h.use === 'dryhop'} onChange={(e) => up({ min: e.target.value })} />
              <input aria-label="Température en °C" inputMode="decimal" value={h.use === 'hopstand' ? h.temp : h.use === 'dryhop' ? '' : '100'} disabled={h.use !== 'hopstand'} onChange={(e) => up({ temp: e.target.value })} />
              <output className="ibu" aria-label="IBU de la ligne">{r ? fmt(r.hopIbu[i] ?? 0, 1) : '–'}</output>
              <button onClick={() => setH(hrows.filter((_, j) => j !== i))} aria-label="Supprimer">×</button>
            </div>
          );
        })}
      </div>
      <p className="hint">Profil aromatique : {hrows.map((h) => HOPS.find((x) => x.id === h.id)?.aroma).join(' / ')}.</p>
      <div className="sec"><h3>Levure</h3></div>
      <div className="row yrow head" aria-hidden="true"><span>Levure</span><span>Atténuation</span><span>Fermentation</span></div>
      <div className="row yrow">
        <select aria-label="Levure" value={yeastId} onChange={(e) => setYeastId(e.target.value)}>
          {YEASTS.map((y) => <option key={y.id} value={y.id}>{y.name}</option>)}
        </select>
        <output className="pct" aria-label="Atténuation typique">{yeast.attenuationPct} %</output>
        <output className="pct" aria-label="Température de fermentation">{yeast.tempC} °C</output>
      </div>
      <details className="mash">
        <summary>Empâtage et volumes d’eau</summary>
        <div className="row msrow head" aria-hidden="true"><span>Étape</span><span>°C</span><span>Min</span><span /></div>
        {mash.map((st, i) => {
          const up = (p: Partial<MashStep>) => setMash(mash.map((x, j) => (j === i ? { ...x, ...p } : x)));
          return (
            <div className="row msrow" key={i}>
              <input aria-label="Étape" value={st.name} onChange={(e) => up({ name: e.target.value })} />
              <input aria-label="Température" inputMode="decimal" value={st.temp} onChange={(e) => up({ temp: e.target.value })} />
              <input aria-label="Minutes" inputMode="decimal" value={st.min} onChange={(e) => up({ min: e.target.value })} />
              <button onClick={() => setMash(mash.filter((_, j) => j !== i))} aria-label="Supprimer">×</button>
            </div>
          );
        })}
        <button className="add" onClick={() => setMash([...mash, { name: 'Palier', temp: '70', min: '15' }])}>+ Palier</button>
        <div className="wgrid">
          {WATER_FIELDS.map(([k, label]) => (
            <label className="field" key={k}><span>{label}</span>
              <input inputMode="decimal" value={water[k]} onChange={(e) => setWater({ ...water, [k]: e.target.value })} /></label>
          ))}
        </div>
        {mw ? (
          <>
            <div className="result"><span>Eau d’empâtage</span><strong>{fmt(mw.strikeL)} L{strikeC !== null ? ` à ${fmt(strikeC, 0)} °C` : ''}</strong></div>
            <div className="result"><span>Eau de rinçage</span><strong>{fmt(mw.spargeL)} L</strong></div>
            <div className="result"><span>Volume pré-ébullition</span><strong>{fmt(mw.preBoilL)} L</strong></div>
          </>
        ) : <p className="hint">Renseignez des malts, un volume et les paramètres d’eau.</p>}
      </details>
      </div>
      <aside className="bilan">
      <h3>Bilan comparé au style {style.id}</h3>
      {r ? (
        <>
          <Gauge label="Densité initiale" value={r.og} range={style.og} d={3} step={0.001} hint="Glissez pour ajuster la quantité de tous les malts" onDragStart={startDrag} onDrag={dragOg} />
          <Gauge label="Densité finale" value={r.fg} range={style.fg} d={3} />
          <Gauge label="Alcool (% vol.)" value={r.abv} range={style.abv} />
          <Gauge label="Amertume (IBU)" value={r.ibu} range={style.ibu} step={1} hint="Glissez pour ajuster les houblons amérisants (le dry hop ne change pas)" onDragStart={startDrag} onDrag={dragIbu} />
          <Gauge label="Couleur (EBC)" value={r.ebc} range={[style.srm[0] * 1.97, style.srm[1] * 1.97]} />
          <p className="hint">Rapport IBU/DI : {fmt(r.buGu, 2)}</p>
        </>
      ) : <p className="hint">Saisissez un volume et un rendement valides.</p>}
      </aside>
    </section>
  );
}
