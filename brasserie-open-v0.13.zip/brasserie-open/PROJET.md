# PROJET : brasserie-open

Outils et application de gestion de brassage amateur. Gratuit, open source (MIT), en français d'abord.

## Décisions
- Licence MIT, projet gratuit pour la communauté.
- Stack prévue : TypeScript, Next.js (PWA hors-ligne), Supabase, Tailwind.
- Compte facultatif : tout doit fonctionner en local sans inscription.
- Unités : métrique par défaut, US en option.
- Aucune copie de code ou de base de données d'autres logiciels.

## Feuille de route
| Semaine | Livrable | État |
|---|---|---|
| 1 | Moteur de calcul testé | fait (v0.1) |
| 2 | Boîte à outils en ligne | v0.2 : réfractomètre, dilution, volume, amertume. Reste : eau, sucre de refermentation |
| 3-4 | Éditeur de recettes, équipements, ingrédients, diagramme multi-houblons | à faire |
| 5 | Mode jour de brassage | à faire |
| 6 | Journal de fermentation | à faire |
| 7 | Stocks et coûts | à faire |
| 8 | Hors-ligne, import/export BeerXML, tests finaux | à faire |

## Recadrage (v0.3)
Objectif principal : **calculateur de recettes** (malts, houblons, levures, styles BJCP, bilan comparé au style). Les outils (réfractomètre, dilution…) passent au second plan. Inspiration fonctionnelle : OpenMaltForge. Conception, code et données originaux, sans copie.

## v0.4
Thème gris clair, bilan à droite et sticky (mise à jour en direct), houblons : FWH et hopstand avec température (équivalent minutes par Arrhenius, à valider).

## v0.5
Thème sombre (gris foncé) avec bouton de bascule, choix mémorisé dans le navigateur. Défaut : thème clair.

## v0.6
Bouton Mémoriser (recette conservée dans le navigateur, rechargée à l’ouverture), en-têtes de colonnes des houblons et IBU par ligne (hopIbu dans calcRecipe).

## v0.7
Houblons : tableau resserré (plus de défilement horizontal sur ordinateur), température modifiable pour toutes les additions sauf le dry hop (100 °C par défaut en ébullition ; plus bas, l’utilisation diminue selon Arrhenius).

## v0.8
Température réservée au hopstand (ébullition, FWH et dry hop sans champ modifiable). FWH : +10 % d’IBU par rapport à la même durée d’ébullition (FWH_FACTOR). Malts : colonne de pourcentage.

## v0.9
Page de recette compactée : style, volume, rendement et levure sur une ligne, boutons d’ajout sur la ligne des titres, espacements réduits. Le bilan garde sa hauteur.

## v0.10
Module Levure restauré. Bilan : curseurs Densité initiale (met à l’échelle tous les malts) et Amertume (met à l’échelle les houblons amérisants, pas le dry hop), au pointeur et au clavier.

## v0.11
Boutons + et − sur les poids (malts 0,1 kg, houblons 5 g, aussi flèches haut/bas). Export et import de la recette en fichier JSON (la recette mémorisée vit dans le navigateur, adresse localhost:5173).

## v0.12
Bibliothèque de recettes nommées (liste, nouvelle, supprimer, indicateur « non mémorisé »), export et import de fiches HTML (données embarquées), module Empâtage et volumes d’eau (paliers, eau d’empâtage, température, rinçage, volume pré-ébullition). Les anciennes recettes uniques sont migrées. Styles BJCP : liste complète à faire (voir ci-dessous).

## À décider : styles BJCP
Les lignes directrices BJCP sont protégées. Ajouter les styles un par un à partir de la source officielle, ou prévoir un import de styles personnalisés.

## v0.13
Styles ajoutés : American Wheat Beer, Lichtenhainer, Berliner Weisse, Oud Bruin, Lambic, Imperial Stout, American Barleywine. Identifiants corrigés (Weissbier 10A, English Barleywine 17D) avec conversion des anciennes recettes. Plages à vérifier sur bjcp.org.

## Moteur de calcul (src/engine)
- gravity.ts : alcool, atténuation, Plato/Brix/SG, correction de température, réfractomètre, dilution, recalibrage de volume
- bitterness.ts : IBU Tinseth, contributions par houblon
- recipe.ts : DI, DF, alcool, IBU, couleur d’une recette
- data/ : malts, houblons, levures, styles (valeurs typiques génériques, à vérifier)
- color.ts : couleur Morey (SRM, EBC)

## À valider avant publication
- Formule réfractomètre en fermentation : comparer avec au moins un calculateur de référence et des mesures réelles.
- Correction de température : comparer avec une table de référence du fabricant du densimètre.
- IBU : la formule ne distingue pas encore houblon en cônes et en pellets, ni le whirlpool.

## À faire ensuite
- Outils d'eau (sels, pH de mash), sucre de refermentation, calcul de la pression en keg.
- Plus de tests avec des recettes de référence réelles.

## Commandes
- `npm install` : installer les dépendances
- `npm test` : lancer les tests
- `npm run typecheck` : vérifier les types
