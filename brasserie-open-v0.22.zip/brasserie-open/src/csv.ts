/** Lecture de catalogues d’ingrédients au format CSV (séparateur ; , ou tabulation, décimale avec virgule ou point). */

const norm = (s: string) => s.toLowerCase().normalize('NFD').replace(/[^a-z0-9]/g, '');

export function parseCsv(text: string): string[][] {
  const src = text.replace(/^\uFEFF/, '');
  const first = src.split(/\r?\n/, 1)[0] ?? '';
  const delim = [';', '\t', ','].map((d) => [d, first.split(d).length] as const).sort((a, b) => b[1] - a[1])[0][0];
  const out: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (quoted) {
      if (c === '"') { if (src[i + 1] === '"') { cell += '"'; i++; } else quoted = false; } else cell += c;
    } else if (c === '"') quoted = true;
    else if (c === delim) { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(cell); out.push(row); row = []; cell = '';
    } else cell += c;
  }
  if (cell || row.length) { row.push(cell); out.push(row); }
  return out;
}

/** Nombre avec virgule ou point, « % » toléré ; une fourchette (« 75-80 ») donne sa moyenne. */
export function toNum(s: string): number {
  const t = s.replace('%', '').replace(/\s+/g, '');
  const f = (x: string) => parseFloat(x.replace(',', '.'));
  const m = /^(\d+(?:[.,]\d+)?)[-–](\d+(?:[.,]\d+)?)$/.exec(t);
  return m ? (f(m[1]) + f(m[2])) / 2 : f(t);
}

type Field = 'name' | 'brand' | 'ebc' | 'extract' | 'att' | 'temp' | 'type' | 'alpha' | 'aroma';
const SYN: Record<Field, string[]> = {
  name: ['nom', 'name', 'produit', 'product', 'malt', 'levure', 'yeast', 'houblon', 'hop', 'variete', 'variety'],
  brand: ['marque', 'brand', 'fabricant', 'supplier', 'maltster', 'fournisseur', 'producteur', 'laboratoire', 'malterie'],
  ebc: ['ebc', 'couleur', 'color', 'colour'],
  extract: ['extrait', 'extract', 'yield', 'rendement'],
  att: ['attenuation', 'attenuationpct', 'att', 'attenuationapparente'],
  temp: ['temperature', 'temp', 'tempc', 'temperaturefermentation', 'fermentation'],
  type: ['type', 'kind'],
  alpha: ['alpha', 'aa', 'alphaacides', 'alphaacide', 'alphaacids', 'alphaacid'],
  aroma: ['aromes', 'arome', 'aroma', 'aromas', 'profil'],
};

/** Lignes du fichier sous forme d’objets ; sans en-tête reconnu, les colonnes sont lues dans l’ordre donné. */
function table(text: string, order: Field[]): { rec: Record<Field, string>; line: number }[] {
  const rows = parseCsv(text).filter((r) => r.some((c) => c.trim()));
  if (!rows.length) return [];
  const head = rows[0].map(norm);
  const idx = new Map<Field, number>();
  for (const f of order) { const i = head.findIndex((h) => SYN[f].includes(h)); if (i >= 0) idx.set(f, i); }
  // En-têtes avec précision (« Couleur (EBC) », « Extrait % ») : on accepte un début de nom connu, avec une liste réduite pour le nom du produit.
  for (const f of order) {
    if (idx.has(f)) continue;
    const taken = new Set(idx.values());
    // pour le nom du produit, « malt » ou « hop » ne comptent pas (risque de confusion avec « Malterie »)
    const syns = f === 'name' ? ['nom', 'name', 'produit', 'product', 'variete', 'variety'] : SYN[f];
    const i = head.findIndex((h, k) => !taken.has(k) && syns.some((x) => x.length >= 3 && h.startsWith(x)));
    if (i >= 0) idx.set(f, i);
  }
  const header = idx.has('name');
  if (!header) order.forEach((f, i) => idx.set(f, i));
  return rows.slice(header ? 1 : 0).map((r, k) => ({
    line: k + (header ? 2 : 1),
    rec: Object.fromEntries(order.map((f) => [f, (r[idx.get(f) ?? -1] ?? '').trim()])) as Record<Field, string>,
  }));
}

export interface Parsed<T> { rows: T[]; errors: string[] }

export function parseMalts(text: string): Parsed<{ name: string; brand: string; ebc: number; extractPct: number }> {
  const out: Parsed<{ name: string; brand: string; ebc: number; extractPct: number }> = { rows: [], errors: [] };
  for (const { rec, line } of table(text, ['name', 'brand', 'ebc', 'extract'])) {
    const ebc = toNum(rec.ebc), extractPct = toNum(rec.extract);
    if (!rec.name) out.errors.push(`ligne ${line} : nom manquant`);
    else if (!(ebc >= 0)) out.errors.push(`ligne ${line} : couleur EBC invalide (${rec.name})`);
    else if (!(extractPct >= 50 && extractPct <= 100)) out.errors.push(`ligne ${line} : extrait invalide (${rec.name})`);
    else out.rows.push({ name: rec.name, brand: rec.brand || 'Importé', ebc, extractPct });
  }
  return out;
}

export function parseYeasts(text: string): Parsed<{ name: string; brand: string; attenuationPct: number; tempC: string; lager: boolean }> {
  const out: Parsed<{ name: string; brand: string; attenuationPct: number; tempC: string; lager: boolean }> = { rows: [], errors: [] };
  for (const { rec, line } of table(text, ['name', 'brand', 'att', 'temp', 'type'])) {
    const attenuationPct = toNum(rec.att);
    if (!rec.name) out.errors.push(`ligne ${line} : nom manquant`);
    else if (!(attenuationPct >= 30 && attenuationPct <= 100)) out.errors.push(`ligne ${line} : atténuation invalide (${rec.name})`);
    else out.rows.push({ name: rec.name, brand: rec.brand || 'Importé', attenuationPct, tempC: rec.temp, lager: /lager|basse/i.test(rec.type) });
  }
  return out;
}

export function parseHops(text: string): Parsed<{ name: string; brand: string; aa: number; aroma: string }> {
  const out: Parsed<{ name: string; brand: string; aa: number; aroma: string }> = { rows: [], errors: [] };
  for (const { rec, line } of table(text, ['name', 'brand', 'alpha', 'aroma'])) {
    const aa = toNum(rec.alpha);
    if (!rec.name) out.errors.push(`ligne ${line} : nom manquant`);
    else if (!(aa >= 0.5 && aa <= 40)) out.errors.push(`ligne ${line} : alpha-acides invalides (${rec.name})`);
    else out.rows.push({ name: rec.name, brand: rec.brand || 'Importé', aa, aroma: rec.aroma });
  }
  return out;
}
