import { describe, expect, it } from 'vitest';
import { parseCsv, parseHops, parseMalts, parseYeasts, toNum } from './csv';

describe('CSV', () => {
  it('lit des champs entre guillemets et les fins de ligne Windows', () => {
    expect(parseCsv('a;b\r\n"x;y";"il dit ""oui"""\r\n')).toEqual([['a', 'b'], ['x;y', 'il dit "oui"']]);
  });
  it('ignore le BOM et détecte la virgule comme séparateur', () => {
    expect(parseCsv('\uFEFFnom,ebc\nPilsen,3.5')).toEqual([['nom', 'ebc'], ['Pilsen', '3.5']]);
  });
  it('lit les nombres avec virgule, pourcentage ou fourchette', () => {
    expect(toNum('3,5')).toBeCloseTo(3.5);
    expect(toNum('81 %')).toBe(81);
    expect(toNum('75-80')).toBeCloseTo(77.5);
    expect(toNum('')).toBeNaN();
  });
  it('lit des malts avec en-têtes français et signale les lignes invalides', () => {
    const { rows, errors } = parseMalts('Nom;Marque;Couleur (EBC);Extrait\nPilsen;Best Malz;3,5;81\nSans extrait;Best Malz;5;\n;X;1;80\n');
    expect(rows).toEqual([{ name: 'Pilsen', brand: 'Best Malz', ebc: 3.5, extractPct: 81 }]);
    expect(errors).toHaveLength(2);
  });
  it('lit des malts sans en-tête, dans l’ordre nom, marque, ebc, extrait', () => {
    expect(parseMalts('Pilsen;Dingemans;3;80').rows[0]).toMatchObject({ name: 'Pilsen', brand: 'Dingemans', ebc: 3, extractPct: 80 });
  });
  it('lit des levures avec fourchette d’atténuation et type lager', () => {
    const { rows } = parseYeasts('name,brand,attenuation,temperature,type\nW-34/70,Fermentis,"80-84",9-15,lager');
    expect(rows[0]).toMatchObject({ attenuationPct: 82, tempC: '9-15', lager: true });
  });
  it('lit des houblons avec en-têtes anglais', () => {
    expect(parseHops('name;brand;aa;aroma\nCitra;Yakima;12,5;agrumes').rows[0]).toMatchObject({ aa: 12.5, aroma: 'agrumes' });
  });
  it('reconnaît des en-têtes précisés et ne confond pas « Malterie » avec le nom', () => {
    const { rows } = parseMalts('Malterie;Nom du malt;Couleur (EBC);Extrait (%)\nBest Malz;Pilsen;3,5;81');
    expect(rows[0]).toMatchObject({ brand: 'Best Malz', ebc: 3.5, extractPct: 81 });
  });
});
