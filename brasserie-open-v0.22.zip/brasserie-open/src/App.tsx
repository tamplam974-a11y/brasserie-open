import { useEffect, useState, type ReactElement } from 'react';
import RecipeBuilder from './RecipeBuilder';
import Ingredients from './Ingredients';
import Recipes from './Recipes';
import HopsTab from './HopsTab';
import {
  abvSimple,
  apparentAttenuation,
  brixToSg,
  dilutionToTargetGravity,
  gravityAfterVolumeChange,
  abvAdvanced,
  abvFromPrimingSugar,
  SUGARS,
  refractometerFinalGravity,
  type SugarKind,
} from './engine';

const num = (s: string) => parseFloat(s.replace(',', '.'));
const positive = (...v: number[]) => v.every((x) => Number.isFinite(x) && x > 0);
const fmt = (x: number, d = 3) =>
  x.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d });

function Field(p: { label: string; value: string; onChange: (v: string) => void; unit?: string }) {
  return (
    <label className="field">
      <span>{p.label}</span>
      <div>
        <input inputMode="decimal" value={p.value} onChange={(e) => p.onChange(e.target.value)} />
        {p.unit && <em>{p.unit}</em>}
      </div>
    </label>
  );
}

function Result({ label, value }: { label: string; value: string }) {
  return (
    <div className="result">
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}

const Hint = () => <p className="hint">Saisissez des valeurs valides pour voir le résultat.</p>;

function Refractometer() {
  const [ob, setOb] = useState('12');
  const [cb, setCb] = useState('7');
  const [k, setK] = useState('1,04');
  const [OB, CB, K] = [num(ob), num(cb), num(k)];
  const valid = positive(OB, CB, K);
  const og = brixToSg(OB / K);
  const fg = refractometerFinalGravity(OB, CB, K);
  return (
    <section>
      <h2>Réfractomètre</h2>
      <p>Estime la densité finale et l’alcool à partir de deux lectures en °Brix (avant et pendant la fermentation).</p>
      <Field label="Brix initial" value={ob} onChange={setOb} unit="°Bx" />
      <Field label="Brix actuel" value={cb} onChange={setCb} unit="°Bx" />
      <Field label="Facteur de correction moût" value={k} onChange={setK} />
      {valid ? (
        <>
          <Result label="Densité initiale" value={fmt(og)} />
          <Result label="Densité actuelle estimée" value={fmt(fg)} />
          <Result label="Alcool estimé" value={`${fmt(abvSimple(og, fg), 1)} %`} />
          <Result label="Atténuation apparente" value={`${fmt(apparentAttenuation(og, fg), 0)} %`} />
        </>
      ) : (
        <Hint />
      )}
    </section>
  );
}

function Dilution() {
  const [v, setV] = useState('20');
  const [sg, setSg] = useState('1,060');
  const [t, setT] = useState('1,050');
  const [v2, setV2] = useState('25');
  const [V, SG, T, V2] = [num(v), num(sg), num(t), num(v2)];
  const dil = positive(V, SG - 1, T - 1) ? dilutionToTargetGravity(V, SG, T) : null;
  const water = dil?.waterToAddL ?? 0;
  return (
    <section>
      <h2>Dilution et volume</h2>
      <p>Volume à atteindre pour une densité cible, en conservant la même quantité de sucre.</p>
      <Field label="Volume actuel" value={v} onChange={setV} unit="L" />
      <Field label="Densité actuelle" value={sg} onChange={setSg} />
      <Field label="Densité cible" value={t} onChange={setT} />
      {dil ? (
        <>
          <Result label="Volume final" value={`${fmt(dil.finalVolumeL, 1)} L`} />
          <Result
            label={water >= 0 ? 'Eau à ajouter' : 'Volume à évaporer'}
            value={`${fmt(Math.abs(water), 1)} L`}
          />
        </>
      ) : (
        <Hint />
      )}
      <h3>Recalibrage après changement de volume</h3>
      <Field label="Nouveau volume (évaporation ou eau)" value={v2} onChange={setV2} unit="L" />
      {positive(V, SG - 1, V2) ? (
        <Result label="Nouvelle densité" value={fmt(gravityAfterVolumeChange(V, SG, V2))} />
      ) : (
        <Hint />
      )}
    </section>
  );
}

function Alcohol() {
  const [og, setOg] = useState('1,050');
  const [fg, setFg] = useState('1,010');
  const [sugar, setSugar] = useState('7');
  const [kind, setKind] = useState<SugarKind>('saccharose');
  const [OG, FG, S] = [num(og), num(fg), num(sugar)];
  const valid = positive(OG - 1, FG - 1) && OG > FG && Number.isFinite(S) && S >= 0;
  const base = abvSimple(OG, FG);
  const added = valid ? abvFromPrimingSugar(S, SUGARS[kind].ethanolGPerG) : 0;
  return (
    <section>
      <h2>Taux d’alcool</h2>
      <p>À partir de la densité initiale (DI), de la densité finale (DF) et du sucre de ressucrage.</p>
      <Field label="Densité initiale (DI)" value={og} onChange={setOg} />
      <Field label="Densité finale (DF)" value={fg} onChange={setFg} />
      <Field label="Sucre de ressucrage" value={sugar} onChange={setSugar} unit="g/L" />
      <label className="field">
        <span>Type de sucre</span>
        <select value={kind} onChange={(e) => setKind(e.target.value as SugarKind)}>
          {Object.entries(SUGARS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
        </select>
      </label>
      {valid ? (
        <>
          <Result label="Alcool avant ressucrage" value={`${fmt(base, 2)} %`} />
          <Result label="Alcool apporté par le ressucrage" value={`+ ${fmt(added, 2)} %`} />
          <Result label="Alcool final" value={`${fmt(base + added, 2)} %`} />
          <Result label="Alcool final (formule précise)" value={`${fmt(abvAdvanced(OG, FG) + added, 2)} %`} />
          <Result label="Atténuation apparente" value={`${fmt(apparentAttenuation(OG, FG), 0)} %`} />
          <p className="hint">Environ 0,07 % d’alcool par gramme de sucre blanc et par litre. La formule précise est préférable au-dessus de 1,070.</p>
        </>
      ) : (
        <Hint />
      )}
    </section>
  );
}

interface Ctx { openReq: { id: string; n: number } | null; open: (id: string) => void }

const TOOLS: { id: string; label: string; view: (c: Ctx) => ReactElement }[] = [
  { id: 'recette', label: 'Recette', view: (c) => <RecipeBuilder openRequest={c.openReq} /> },
  { id: 'recettes', label: 'Mes recettes', view: (c) => <Recipes onOpen={c.open} /> },
  { id: 'ingredients', label: 'Ingrédients', view: () => <Ingredients /> },
  { id: 'houblons', label: 'Houblons', view: () => <HopsTab /> },
  { id: 'refracto', label: 'Réfractomètre', view: () => <Refractometer /> },
  { id: 'dilution', label: 'Dilution et volume', view: () => <Dilution /> },
  { id: 'alcool', label: 'Taux d’alcool', view: () => <Alcohol /> },
];

type Theme = 'light' | 'dark';

function initialTheme(): Theme {
  try {
    return localStorage.getItem('theme') === 'dark' ? 'dark' : 'light';
  } catch {
    return 'light';
  }
}

export default function App() {
  const [tool, setTool] = useState(TOOLS[0].id);
  const [openReq, setOpenReq] = useState<{ id: string; n: number } | null>(null);
  const [theme, setTheme] = useState<Theme>(initialTheme);
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    try {
      localStorage.setItem('theme', theme);
    } catch {
      /* stockage indisponible : le choix ne sera pas mémorisé */
    }
  }, [theme]);
  return (
    <main>
      <header>
        <div>
          <h1>Brasserie Open</h1>
          <p className="sub">Boîte à outils gratuite du brasseur amateur</p>
        </div>
        <button
          className="theme"
          onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          aria-label={theme === 'dark' ? 'Passer au thème clair' : 'Passer au thème sombre'}
        >
          {theme === 'dark' ? '☀ Clair' : '☾ Sombre'}
        </button>
      </header>
      <nav>
        {TOOLS.map((t) => (
          <button key={t.id} className={t.id === tool ? 'on' : ''} onClick={() => setTool(t.id)}>
            {t.label}
          </button>
        ))}
      </nav>
      {TOOLS.map((t) => (
        <div className="tool" key={t.id} hidden={t.id !== tool}>{t.view({ openReq, open: (id) => { setOpenReq({ id, n: Date.now() }); setTool('recette'); } })}</div>
      ))}
      <footer>
        Calculs indicatifs : vérifiez toujours avec vos propres mesures.<br />
        Recettes mémorisées dans ce navigateur, pour l’adresse {window.location.host}.
      </footer>
    </main>
  );
}
