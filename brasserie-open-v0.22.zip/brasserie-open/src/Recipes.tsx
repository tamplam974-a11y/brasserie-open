import { useState } from 'react';
import { srmColor } from './beerColor';
import { STYLES } from './data/styles';
import { compute, loadLibrary } from './library';

type Sort = 'name' | 'abv' | 'ibu' | 'ebc' | 'og';
const f = (x: number, d = 1) => x.toLocaleString('fr-FR', { minimumFractionDigits: d, maximumFractionDigits: d });

/** Toutes les recettes mémorisées, en cartes ou en liste. */
export default function Recipes({ onOpen }: { onOpen: (id: string) => void }) {
  const [view, setView] = useState<'cards' | 'list'>('cards');
  const [q, setQ] = useState('');
  const [sort, setSort] = useState<Sort>('name');
  const lib = loadLibrary();
  const rows = lib.items
    .map(({ id, data }) => ({ id, data, r: compute(data), style: STYLES.find((s) => s.id === data.styleId), current: id === lib.current }))
    .filter((x) => `${x.data.name} ${x.data.styleId} ${x.style?.name ?? ''}`.toLowerCase().includes(q.trim().toLowerCase()))
    .sort((a, b) => {
      if (sort === 'name') return a.data.name.localeCompare(b.data.name, 'fr');
      const key = { abv: 'abv', ibu: 'ibu', ebc: 'ebc', og: 'og' }[sort] as 'abv' | 'ibu' | 'ebc' | 'og';
      return (b.r?.[key] ?? 0) - (a.r?.[key] ?? 0);
    });
  const styleLabel = (x: (typeof rows)[number]) => (x.style ? `${x.style.id} – ${x.style.name}` : x.data.styleId);
  return (
    <div className="wide">
      <section>
        <div className="top">
          <h2>Mes recettes <small>({lib.items.length})</small></h2>
          <div className="seg" role="group" aria-label="Affichage">
            <button className={view === 'cards' ? 'on' : ''} onClick={() => setView('cards')}>Cartes</button>
            <button className={view === 'list' ? 'on' : ''} onClick={() => setView('list')}>Liste</button>
          </div>
        </div>
        <div className="libbar">
          <input className="nm" placeholder="Rechercher (nom, style)" aria-label="Rechercher une recette" value={q} onChange={(e) => setQ(e.target.value)} />
          <select aria-label="Trier par" value={sort} onChange={(e) => setSort(e.target.value as Sort)}>
            <option value="name">Trier par nom</option>
            <option value="abv">Alcool décroissant</option>
            <option value="ibu">Amertume décroissante</option>
            <option value="ebc">Couleur décroissante</option>
            <option value="og">Densité décroissante</option>
          </select>
        </div>
        {rows.length === 0 && <p className="hint">Aucune recette ne correspond.</p>}
        {view === 'cards' ? (
          <div className="rcards">
            {rows.map((x) => (
              <article className="rcard" key={x.id}>
                <div className="swatch" style={{ background: x.r ? srmColor(x.r.srm) : 'var(--line)' }} />
                <h3>{x.data.name}{x.current && <small> · ouverte</small>}</h3>
                <p className="sub">{styleLabel(x)} · {x.data.vol} L</p>
                {x.r && (
                  <dl className="stats">
                    <div><dt>DI</dt><dd>{f(x.r.og, 3)}</dd></div>
                    <div><dt>Alcool</dt><dd>{f(x.r.abv)} %</dd></div>
                    <div><dt>IBU</dt><dd>{f(x.r.ibu, 0)}</dd></div>
                    <div><dt>EBC</dt><dd>{f(x.r.ebc, 0)}</dd></div>
                  </dl>
                )}
                <p className="sub">{x.data.mrows.length} malt(s) · {x.data.hrows.length} houblon(s)</p>
                <button className="save" onClick={() => onOpen(x.id)}>Ouvrir</button>
              </article>
            ))}
          </div>
        ) : (
          <div className="tablewrap">
            <table className="tbl">
              <thead><tr><th /><th>Recette</th><th>Style</th><th>Vol.</th><th>DI</th><th>Alcool</th><th>IBU</th><th>EBC</th><th /></tr></thead>
              <tbody>
                {rows.map((x) => (
                  <tr key={x.id}>
                    <td><i className="dot" style={{ background: x.r ? srmColor(x.r.srm) : 'var(--line)' }} /></td>
                    <td><b>{x.data.name}</b>{x.current && <small> · ouverte</small>}</td>
                    <td>{styleLabel(x)}</td>
                    <td>{x.data.vol} L</td>
                    <td>{x.r ? f(x.r.og, 3) : '–'}</td>
                    <td>{x.r ? `${f(x.r.abv)} %` : '–'}</td>
                    <td>{x.r ? f(x.r.ibu, 0) : '–'}</td>
                    <td>{x.r ? f(x.r.ebc, 0) : '–'}</td>
                    <td><button className="add" onClick={() => onOpen(x.id)}>Ouvrir</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <p className="hint">Ces chiffres sont ceux de la dernière version mémorisée de chaque recette.</p>
      </section>
    </div>
  );
}
