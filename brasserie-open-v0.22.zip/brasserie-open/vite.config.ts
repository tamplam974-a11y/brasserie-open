import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' : le site fonctionne depuis n’importe quel sous-dossier (GitHub Pages).
// Port fixe : les recettes mémorisées dépendent de l’adresse (localhost:5174). Si le port est pris, Vite s’arrête au lieu d’en changer.
export default defineConfig({ base: './', plugins: [react()], server: { port: 5174, strictPort: true } });
